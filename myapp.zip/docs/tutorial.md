## Setting up Phaser on your server

* The first step is to setup Phaser on your computer. Download the phaser package and store it somewhere on your computer. So we start with a generic html template.


<!DOCTYPE html>
<html lang = 'en-us'>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rpg</title>
</head>

<body>
</body>

* In the <head> of the html link the phaser library

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rpg</title>
    <script src="assets/javascript/phaser.js"></script>
</head>

* Now create a "game.js" file and link it at the bottom of the <body>

<html lang = 'en-us'>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rpg</title>
</head>

<body>
    <script type='text/javascript' src='assets/javascript/game.js'></script>
</body>

* 